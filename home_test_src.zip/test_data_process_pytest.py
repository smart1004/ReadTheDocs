# -*- coding: utf-8 -*-
# test_data_process_pytest.py
import pytest
import data_process
from pandas.io.json import json_normalize
from pandas.util.testing import assert_frame_equal
@pytest.fixture()
def set_up_data(request):
    data = [
        {
            "id": 1,
            "name": "Leanne Graham",
            "username": "Bret",
            "email": "Sincere@april.biz",
            "address": {
                "street": "Kulas Light",
                "suite": "Apt. 556",
                "city": "Gwenborough",
                "zipcode": "92998-3874",
                "geo": {
                    "lat": "-37.3159",
                    "lng": "81.1496"
                }
            },
            "phone": "1-770-736-8031 x56442",
            "website": "hildegard.org",
            "company": {
                "name": "Romaguera-Crona",
                "catchPhrase": "Multi-layered client-server",
                "text": "harness real-time e-markets"
            }
        },
        {
            "id": 2,
            "name": "Ervin Howell",
            "username": "Antonette",
            "email": "Shanna@melissa.tv",
            "address": {
                "street": "Victor Plains",
                "suite": "Suite 879",
                "city": "Wisokyburgh",
                "zipcode": "90566-7771",
                "geo": {
                    "lat": "-43.9509",
                    "lng": "-34.4618"
                }
            },
            "phone": "010-692-6593 x09125",
            "website": "anastasia.net",
            "company": {
                "name": "Deckow-Crist",
                "catchPhrase": "Proactive didactic contingency",
                "text": "synergize scalable supply-chains"
            }
        }
    ]


    def tear_down():
        pass

    request.addfinalizer(tear_down)
    return data

def test_data_structure(set_up_data):
    """
    The nested data structure should be flattened
    into a single record. We'll just use pandas
    for this.
    """
    expected_columns = ['id', 'name', 'username', 'email',
        'address.street', 'address.suite',
        'address.city', 'address.zipcode',
        'address.geo.lat', 'address.geo.lng',
        'phone', 'website', 'company.name',
        'company.catchPhrase', 'company.text']
    dataframe = json_normalize(set_up_data)
    actual_columns = dataframe.columns
    assert set(expected_columns) == set(actual_columns)

def test_remove_duplicate_data(set_up_data):
    """
    Remove duplicate data from an input dataset
    as defined by a `by variable` parameter.
    """
    data_with_duplicates = set_up_data + set_up_data
    actual = data_process.remove_duplicates(data_with_duplicates,
                                            'users', 'name').to_df()
    # convert both data objects to pandas dataframes
    expected = json_normalize(set_up_data)
    # compare
    assert_frame_equal(expected, actual)

def test_remove_variable(set_up_data):
    """
     Remove variable from an existing
     SAS dataset using SAS Data Step.
     """
    columns = ['id', 'email', 'address.street',
               'address.suite', 'address.city',
               'address.zipcode', 'address.geo.lat',
               'address.geo.lng', 'phone', 'website',
               'company.catchPhrase', 'company.text']
    sasdf = data_process.remove_variable('users', 'name')
    assert 'name' not in sasdf.to_df().columns
    sasdf = data_process.remove_variable('users', 'username')
    assert 'username' not in sasdf.to_df().columns
    sasdf = data_process.remove_variable('users', 'company.name')
    assert 'company.name' not in sasdf.to_df().columns
    assert set(sasdf.to_df().columns) == set(columns)
    # make sure an Error is raised if data != exist
    with pytest.raises(ValueError):
        data_process.remove_variable('bogus_data_name', 'name')
