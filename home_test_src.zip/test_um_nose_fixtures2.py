# import nose
# http://pythontesting.net/framework/nose/nose-introduction/#example 

# from unnecessary_math import multiply
from unnecessary_math.multiply1 import multiply
from nose import with_setup  # optional


class TestUM:

    @classmethod
    def setup_class(cls):
        print("1.setup_class() before any methods in this class")

    def setup(self):
        print("2.TestUM:setup() before each test method")

    def teardown(self):
        print("10.TestUM:teardown() after each test method")

    @classmethod
    def teardown_class(cls):
        print("99.teardown_class() after any methods in this class")

    def test_numbers_5_6(self):
        print('test_numbers_5_6()  <============================ actual test code')
        assert multiply(5, 6) == 30

    def test_strings_b_2(self):
        print('test_strings_b_2()  <============================ actual test code')
        assert multiply('b', 2) == 'bb'

# nosetests test_um_nose_fixtures1.py
# nosetests -s test_um_nose_fixtures2.py