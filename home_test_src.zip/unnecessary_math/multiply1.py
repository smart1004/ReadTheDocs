

def multiply(x1, x2):
    return x1*x2
