# -*- coding: utf-8 -*-
#https://www.sas.com/content/dam/SAS/support/en/sas-global-forum-proceedings/2018/2347-2018.pdf

# test_data_process_unittest.py
import unittest
import data_process
from pandas.io.json import json_normalize

from pandas.util.testing import assert_frame_equal

class TestDataProcess(unittest.TestCase):
    def setUp(self):
        self.data = [
            {
                "id": 1,
                "name": "Leanne Graham",
                "username": "Bret",
                "email": "Sincere@april.biz",
                "address": {
                    "street": "Kulas Light",
                    "suite": "Apt. 556",
                    "city": "Gwenborough",
                    "zipcode": "92998-3874",
                    "geo": {
                        "lat": "-37.3159",
                        "lng": "81.1496"
                    }
                },
                "phone": "1-770-736-8031 x56442",
                "website": "hildegard.org",
                "company": {
                    "name": "Romaguera-Crona",
                    "catchPhrase": "Multi-layered client-server",
                    "text": "harness real-time e-markets"
                }
            },
            {
                "id": 2,
                "name": "Ervin Howell",
                "username": "Antonette",
                "email": "Shanna@melissa.tv",
                "address": {
                    "street": "Victor Plains",
                    "suite": "Suite 879",
                    "city": "Wisokyburgh",
                    "zipcode": "90566-7771",
                    "geo": {
                        "lat": "-43.9509",
                        "lng": "-34.4618"
                    }
                },
                "phone": "010-692-6593 x09125",
                "website": "anastasia.net",
                "company": {
                    "name": "Deckow-Crist",
                    "catchPhrase": "Proactive didactic contingency",
                    "text": "synergize scalable supply-chains"
                }
            }
            ]

    def test_data_structure(self):
        """
        The nested data structure should be flattened
        into a single record. We'll just use pandas
         for this.
         """
        expected_columns = ['id', 'name', 'username', 'email',
                            'address.street', 'address.suite',
                            'address.city', 'address.zipcode',
                            'address.geo.lat', 'address.geo.lng',
                            'phone', 'website', 'company.name',
                            'company.catchPhrase', 'company.text']
        dataframe = json_normalize(self.data)
        actual_columns = dataframe.columns
        self.assertEqual(set(expected_columns), set(actual_columns))

    def test_remove_duplicate_data(self):
        """
         Remove duplicate data from an input dataset
         as defined by a `by variable` parameter.
         """
        data_with_duplicates = self.data + self.data

        actual = data_process.remove_duplicates(data_with_duplicates,
                                                'users', 'name').to_df()
        # convert both data objects to pandas dataframes
        expected = json_normalize(self.data)
        # compare
        assert_frame_equal(expected, actual)

    def test_remove_variable(self):
        """
         Remove variable from an existing
         SAS dataset using SAS Data Step.
         """
        columns = ['id', 'email', 'address.street',
                   'address.suite', 'address.city',
                   'address.zipcode', 'address.geo.lat',
                   'address.geo.lng', 'phone', 'website',
                   'company.catchPhrase', 'company.text']
        sasdf = data_process.remove_variable('users', 'name')
        self.assertTrue('name' not in sasdf.to_df().columns)
        sasdf = data_process.remove_variable('users', 'username')
        self.assertTrue('username' not in sasdf.to_df().columns)
        sasdf = data_process.remove_variable('users', 'company.name')
        self.assertTrue('company.name' not in sasdf.to_df().columns)
        self.assertEqual(set(sasdf.to_df().columns), set(columns))
        # make sure an Error is raised if data != exist

        self.assertRaises(ValueError,
                          data_process.remove_variable,
                          'bogus_data_name', 'name')

    def tearDown(self):
        pass

if __name__ == '__main__':
 unittest.main()
