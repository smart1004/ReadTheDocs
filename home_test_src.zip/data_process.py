# -*- coding: utf-8 -*-
# data_process.py
# import saspy
from pandas.io.json import json_normalize
# initialize the SAS session
# sas = saspy.SASsession()


def remove_duplicates(data, name, sort_variable):
    """
    Sort and deduplicate normalized data
    using PROC SORT.
    """
    dataframe = json_normalize(data)
    ds = 'sort data'

    # sas.df2sd(dataframe, table=name)
    # sas.submit(
    # f"""
    # proc sort data={name} NODUPKEY;
    # by DESCENDING '{sort_variable}'n;
    # run;
    # quit;
    # """
    # )
    # return sas.sasdata(f"{name}")
    return ds

def remove_variable(name, variable):
    """
    Drop a dataset variable using
    Data Step.
    """
    if sas.exist(name):
        sas.submit(f"""
        data {name};
        set {name};
        drop '{variable}'n;
        run;"""
        )
    return sas.sasdata(f"{name}")
    # raise ValueError('Dataset does not exist.')
